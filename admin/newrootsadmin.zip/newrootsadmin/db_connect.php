<?php
    // Create connection
    $conn = new mysqli("localhost","root","","newroots_newroots_india") or die("Connection Failed");
?>
